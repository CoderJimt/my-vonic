import Vue from 'vue'
import Vuex from 'vuex'
import Api from '../api/config.js' //网络数据接口能力
import {MsgType} from '../common/constants.js';


Vue.use(Vuex);

const state = {
	token:'12345',
	count:0
}

const mutations = {
	setToken(t){
		state.token=t;
	},
	setCounter(s,param){
		state.count = param.value;
	},
	increment(s){
		state.count = s.count + 5;
	},
	decrement(s){
		state.count = s.count - 3;
	}

}


const actions = {
	'setCounter':({commit},param) =>{
		console.info(param);
		commit('setCounter',param);
	} ,
	'increment':({commit}) =>commit('increment'),
    'decrement':({commit}) => commit('decrement'),
    'AJAX_COUNT':({commit},param) =>{
    	console.info('ajax request param:'+param);
    	return new Promise(function(resolve, reject) {
    			$loading.show('正在计算');
    			setTimeout(() => {
    				console.info('ajax request responce  and view update!');
    				var nowval=parseInt(Math.random()*10,10);
			        commit('setCounter',{value:nowval});
			        $loading.hide();
			        if(nowval>0){
			        	resolve(false);
			        }else {
			        	resolve(true);
			        }
			     }, 3000)
        	});
    },
    'LOGIN':({commit},param) =>{
    	return new Promise(function(resolve, reject) {
    			Api.login(param).then((res) => {
    				resolve(res);
    			})

    			
        	});
    },
    'LOGOUT':({commit},param) =>{
    	return new Promise(function(resolve, reject) {
    			Api.logout(param).then((res) => {
    				resolve(res);
    			})

    			
        	});
    }
}

const getters = {

}

export default new Vuex.Store({
	state,
	mutations,
	actions,
	getters
})