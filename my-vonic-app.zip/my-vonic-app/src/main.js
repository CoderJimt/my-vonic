//运行必备
import Vue from 'vue'
import Vonic from 'vonic/src/index.js'
import store from './vuex/store.js' //vuex 能力 store

//页面组件 Page Components
import Index from './components/Index.vue'
import About from './components/About.vue'
import Standard from './components/Standard.vue'
import MainForm from './components/Form.vue'
import Setting from './components/Setting.vue'

import Counter from './components/Counter.vue'


//禁用浏览器 历史记录
//Vonic.app.setConfig('pushMethod', 'replace');

//路由定义 Routes
const routes = [
  { path: '/', component: Index },
  { path: '/about', component: About },
  { path: '/login', component: Standard },
  { path: '/standard', component: Standard },
  { path: '/mainform', component: MainForm },
  { path: '/setting', component: Setting },
  { path: '/counter', component: Counter }


];



//路由设置
Vue.use(Vonic.app, {
  routes,
  store
})
