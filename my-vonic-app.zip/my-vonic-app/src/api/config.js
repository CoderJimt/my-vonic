
//配置
const Env = {
  baseURL: 'http://127.0.0.1:8080/VonicServer',
	isMockTest:true,
  logAjax:true
}
if (Env.isMockTest) {
  console.info('-----isMockTest:'+Env.isMockTest);
  require('./mock/mockData.js');
}

//依赖
import store from '../vuex/store.js' //vuex 能力 store
import {MsgType} from '../common/constants.js';


//网络Api能力
import axios from 'axios'

axios.defaults.baseURL = Env.baseURL;
//axios.defaults.headers.common['Authorization'] = AUTH_TOKEN;
axios.defaults.method = 'post';
axios.defaults.timeout = 8000 ;
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';

// http request 拦截器
axios.interceptors.request.use(
    config => {
        if (store.state.token) {  // 判断是否存在token，如果存在的话，则每个http header都加上token
            //console.info('---already has token:'+store.state.token);
            config.headers.Authorization = `token ${store.state.token}`;
        }

        $loading.show();//请求等待特效

        console.info('---请求:'+config.url);
        console.info(config.data);

        return config;
    },
    err => {
        return Promise.reject(err);
    });

// http response 拦截器
axios.interceptors.response.use(
    response => {
        $loading.hide();//关闭请求等待特效
        if(Env.logAjax){
           console.info('---响应 response.data:');
           console.info(response.data);
        }
        if(response.data.show){
          $toast.show(response.data.msg, 3000)
        }
        return response;
    },
    error => {
        console.info(error);
        if (error.response) {
            switch (error.response.status) {
                case 401://未授权
                    // 返回 401 清除token信息并跳转到登录页面
                    store.commit('LOGOUT');
                    $router.replace({
                         path: 'login',
                         query: {redirect: $router.currentRoute.fullPath}
                    })
            }
        }else {
           $toast.show('请求异常', 3000);
        }
       
        return Promise.reject(error)   // 返回接口返回的错误信息
    });


//业务Api接口定义
export default {

  login (param) { // 登录
    return axios.post('/api/login', param).then((res) => {  return res.data; });
  },
  logout (param) { // 注销
    return axios.post('/api/logout', param).then((res) => {  return res.data; });
  }



};