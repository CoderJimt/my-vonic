import Mock from 'mockjs';
import {MsgType} from '../../common/constants.js';

// 模拟登录数据
Mock.mock(/\/api\/login/, {
  type: MsgType.SUCCESS, show: false, msg: '登录成功！', title: null, bean: null
});

// 模拟注销数据
Mock.mock(/\/api\/logout/, {
  type: MsgType.SUCCESS, show: false, msg: '注销成功'
});
