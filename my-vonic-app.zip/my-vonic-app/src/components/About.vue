<template>
  <div class="page has-navbar" v-nav="{ title: '关于', showBackButton: true }">
    <div class="page-content text-center">
      <p class="padding">本应用以vuejs2.x, ionic样式组件为核心，使用了vuex ,axios技术，具备大多数应用所需要的能力，比如网络数据请求，组件间状态通讯, 可二次开发为实际项目或产品</p>

      <p class="padding">本应用使用了mockjs，可进行前后端分离，即本应用可独立于后端开发</p>
    </div>
  </div>
</template>
