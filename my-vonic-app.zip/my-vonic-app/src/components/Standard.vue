<template>
  <div class="page has-navbar" v-nav="{ title: '标准示例', showBackButton: true }">
    <div class="page-content text-center" >
        <h2 class="padding" v-text="imsg"></h2>

        <von-input 
		  type="text" 
		  v-model="username" 
		  placeholder="登录账号/手机号" 
		  label="用户名">
		</von-input>

        <von-input 
		  type="password" 
		  v-model="password" 
		  placeholder="请输入密码" 
		  label="密码">
		</von-input>


		<list>
		  <item>
		      <md-button class="button button-positive button-block" @click.native="onClick()">
		        登录
		      </md-button>
		  </item>
		</list>

      
      

    </div>
  </div>
</template>
<script>
  import {MsgType} from '../common/constants.js';

  export default {
  	data () {
      return {
        imsg: 'Hello,Guy',
        username:'admin',
        password:''
      }
    },
    methods: {
      onClick() {
      	if(this.password==''){
      		$toast.show("请输入密码!");
      		return;
      	}
        this.$store.dispatch('LOGIN',{username:this.username,password:this.password}).then((res) => {
            if(MsgType.SUCCESS==res.type){
              $router.push('/mainform');//到登录后页
            }
          
		    });

      }
    }
  }
</script>