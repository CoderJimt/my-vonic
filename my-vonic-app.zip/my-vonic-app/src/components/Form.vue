<template>
  <div class="page has-navbar" v-nav="{ title: '移动欢迎你', showBackButton: false , showMenuButton:true, menuButtonText:'设置',onMenuButtonClick:onSetting }">
    <div class="page-content text-center">


        <tabs :tab-items="tabs" :tab-index="tabIndex" :on-tab-click="onTabClick"></tabs>
 
<div v-show="tabIndex==0" >
        <search v-model="keywords" placeholder="输入关键字"
         :on-search="onSearch" :on-cancel="onCancel"
         cancelText="X"
         >
        </search>

      <div class="padding" v-show="searching">
        <span v-if="keywords">正在搜索'{{keywords}}'.</span>
      </div>

      <accordion>
        <accordion-item title="农夫" content-height="110">
          <p>
            如果有一天我能够拥有一个大果园，
            我愿放下所有追求做个农夫去种田，
            每一个早晨我耕耘在绿野田园，
            每一个黄昏我守望在乡间的麦田。
            我会把忧虑都融化在夕阳里，
            让孤独的心等待秋收的欢喜。
          </p>
        </accordion-item>
        <accordion-item title="渔夫" content-height="110">
          <p>
            如果有一天我能够拥有一条渔船，
            我愿放下所有执着做个渔夫住在海边，
            每一个早晨我航行在晨曦的海面，
            每一个黄昏我遥望在无际的海云间。
            我会把思绪都消失在波涛里，
            让澎湃的心等待风雨后的平息。
          </p>
        </accordion-item>
      </accordion>

      <list>
            <item>
          <md-button class="button button-balanced button-block" @click.native="onCounter()">
                计数器
          </md-button>
        </item>
      </list>

      <von-input 
        type="text" 
        v-model="nickname" 
        placeholder="输入你的昵称" 
        label="昵称">
      </von-input>

      <datepicker v-model="birthday" label="你的生日" date-format="yyyy-mm-dd"></datepicker>

      <div class="item item-divider">
        选择您所属的行政区划：
      </div>
      <cascade :fields="fields" :data="cities" :value="value" :on-change="onChange"></cascade>



      <div class="item item-divider">
        选择性别:
      </div>

      <von-radio :options="genderOptions" v-model="gender"></von-radio>

      <p class="padding">
        option index: {{ gender }}<br>
        option text: {{ genderOptions[gender] }}
      </p>
     
      <div class="item item-divider">
        选择感兴趣的板块:
      </div>

      <von-checkbox :options="topics" v-model="chosenTopics" theme="positive"></von-checkbox>

      <p class="padding">
        chosen topics: {{ chosenTopics }}
      </p>






</div>	

<div v-show="tabIndex==1" >
    <scroll class="page-content"
            :on-refresh="onRefresh"
            :on-infinite="onInfinite">
      <item v-for="(item, index) in items" @click.native="onItemClick(index)" :class="{'item-stable': index % 2 == 0}">
        {{ item }}
      </item>

      <div v-if="infiniteCount >= 2" slot="infinite" class="text-center">没有更多数据</div>
    </scroll>

</div>


<div v-show="tabIndex==2" >
待研究



</div>

     
    
    </div>

  </div>
</template>
<script>
  export default {
  	data () {
      return {
      
        volume2:20,
        
        tabs: ["常用组件","列表组件","拍照上传"],
        tabIndex: 0,


        keywords: '',
        searching: false,
        gender: 0,
        genderOptions: ["男", "女"],
        chosenTopics: [],
        topics: ["娱乐", "电影", "减肥", "搞笑", "科技"],
        items: [],
        infiniteCount: 0,
        fields: [
          "省", "市", "区"
        ],

        cities: [
          ['北京市', '市辖区', '东城区'],
          ['广东省', '广州市', '天河区'],
          ['广东省', '广州市', '白云区'],
          ['广东省', '广州市', '从化区']
          // ...
        ],
        value: [],

        nickname:'小猫呢',
        birthday:'1988-10-03'
      }
    },
    mounted() {
      for (let i = 1; i <= 20; i++) {
        this.items.push(i + ' - keep walking, be 2 with you.')
      }
      this.top = 1
      this.bottom = 20

      setTimeout(()=>{
        this.volume2++;
      },5000);
    },
    methods: {
      onTabClick(index) {
        this.tabIndex = index;
      },
      onSetting(){
        $router.push('/setting');
      },
      onCounter(){
        $router.push('/counter');
      },
      onSearch(keywords) {
        this.searching = true;
      },
      onCancel() {
        this.searching = false;
        this.keywords = ''
      },

      onRefresh(done) {
        setTimeout(() => {
          let start = this.top - 1
          for (let i = start; i > start - 10; i--) {
            this.items.splice(0, 0, i + ' - keep walking, be 2 with you.')
          }
          this.top = this.top - 10;

          done()
        }, 1500)
      },

      onInfinite(done) {
        setTimeout(() => {
          if (this.infiniteCount < 2) {
            let start = this.bottom + 1
            for (let i = start; i < start + 10; i++) {
              this.items.push(i + ' - keep walking, be 2 with you.')
            }
            this.bottom = this.bottom + 10;

            this.infiniteCount++
          }

          done()
        }, 1500)
      },

      onItemClick(index) {
        console.log(index)
      },
      onChange(value) {
        this.value = value
        console.log(this.value)
      }

    }
  }
</script>