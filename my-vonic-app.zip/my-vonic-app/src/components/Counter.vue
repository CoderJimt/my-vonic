<template>
  <div class="page has-navbar" v-nav="{ title: '计数器', showBackButton: true }">
    <div class="page-content text-center">
      <h2 class="padding">Count: {{$store.state.count}} </h2>

      <md-button class="button button-positive" @click.native="increment()">
		        +5
	  </md-button>
	  <md-button class="button button-positive" @click.native="decrement()">
		        -3
	  </md-button>
	   <md-button class="button button-positive" @click.native="resetCounter()">
		        随机异步重置
	  </md-button>

    </div>
  </div>
</template>
<script>

export default {
	methods: {
		increment(){
			console.info('+5');
			this.$store.dispatch('increment');

		},
		decrement(){
			console.info('-3');
			this.$store.dispatch('decrement');
		},
		resetCounter(){
			console.info('-resetCounter');
			//this.$store.dispatch('setCounter',{value:0});
			this.$store.dispatch('AJAX_COUNT').then((isOK)=>{
			   console.log(isOK) // ok
			   if(isOK){
			   		$dialog.alert({
					  // 效果
					  effect: 'default',
					  // 标题
					  title: '提示', 
					  // 内容
					  content: '恭喜你，重置成功！',
					  // 按钮文本
					  okText: '确定',
					  // 按钮主题
					  okTheme: 'assertive'
					})
			   }
			})

			
		}
		

	}
}

</script>

