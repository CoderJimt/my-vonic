<template>
  <div class="page has-navbar" v-nav="{ title: '设置', showBackButton: true }">
    <div class="page-content text-center">


      
      <von-toggle :text="toggleText" v-model="pushNotification"></von-toggle>

      <von-range
        v-model="volume2"
        :min="min"
        :max="max"
        theme="balanced"
      >
        <!-- 通过 text-left / text-right 两个 slot 对 range slider 左右两边的文字进行分发 -->
        <i class="icon ion-volume-low" slot="text-left"></i>
        <i class="icon ion-volume-high" slot="text-right"></i>
      </von-range>

    <div class="item item-divider">
        我的消息<badge :num="volume2" v-show="volume2>0"></badge>
      </div>

    <list>
      <item>
          <md-button class="button button-assertive button-block" @click.native="onLogout()">
            注销
          </md-button>
      </item>
    </list>

     
    
    </div>

  </div>
</template>
<script>
  export default {
  	data () {
      return {
        toggleText: "开启推送",
        pushNotification: true,
        volume2:20,
        min:0,
        max:100

        
      }
    },
    mounted() {
      
    },
    methods: {
      
      onLogout(){

        /* Confirm 确认框 */
        $dialog.confirm({
          effect:'scale',
          // 设置为ios样式
          //theme: 'ios',
          // 标题
          title: '确认要退出应用?',
          // 取消按钮文本
          cancelText: '取消',
          // 确定按钮文本
          okText: '确认'
        }).then((sure) => {
          if(sure){
            this.$store.dispatch('LOGOUT',{}).then((res) => {
                $router.go(-2);//返回到登录页
                // $router.replace({
                //          path: 'login',
                //          query: {redirect: $router.currentRoute.fullPath}
                //     })
            });
            
          }
          
        })


        
      }

    }
  }
</script>